package vo;

public class MovieVO {
	private int mvRank;
	private String mvTitle;
	private String mvScore;
	private String mvDir;
	private String mvAct;
	private String mvInfo;
	private String mvDate;
	private String mvGenre;
	private String mvPos;
	


	public int getMvRank() {
		return mvRank;
	}
	public void setMvRank(int mvRank) {
		this.mvRank = mvRank;
	}
	public String getMvTitle() {
		return mvTitle;
	}
	public void setMvTitle(String mvTitle) {
		this.mvTitle = mvTitle;
	}
	public String getMvScore() {
		return mvScore;
	}
	public void setMvScore(String mvScore) {
		this.mvScore = mvScore;
	}
	public String getMvDir() {
		return mvDir;
	}
	public void setMvDir(String mvDir) {
		this.mvDir = mvDir;
	}
	public String getMvAct() {
		return mvAct;
	}
	public void setMvAct(String mvAct) {
		this.mvAct = mvAct;
	}
	public String getMvInfo() {
		return mvInfo;
	}
	public void setMvInfo(String mvInfo) {
		this.mvInfo = mvInfo;
	}
	public String getMvDate() {
		return mvDate;
	}
	public void setMvDate(String mvDate) {
		this.mvDate = mvDate;
	}
	public String getMvGenre() {
		return mvGenre;
	}
	public void setMvGenre(String mvGenre) {
		this.mvGenre = mvGenre;
	}
	public String getMvPos() {
		return mvPos;
	}
	public void setMvPos(String mvPos) {
		this.mvPos = mvPos;
	}
	
}
