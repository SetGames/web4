package vo;

public class MemberVO {
	private String mbId;
	private String mbPw;
	private String mbIrum;
	private String mbEmail;
	private String mbBirthYear;
	private String mbPoint;
	private String mbAdmin;
	
	public String getMbId() {
		return mbId;
	}
	public void setMbId(String mbId) {
		this.mbId = mbId;
	}
	public String getMbPw() {
		return mbPw;
	}
	public void setMbPw(String mbPw) {
		this.mbPw = mbPw;
	}
	public String getMbIrum() {
		return mbIrum;
	}
	public void setMbIrum(String mbIrum) {
		this.mbIrum = mbIrum;
	}
	public String getMbEmail() {
		return mbEmail;
	}
	public void setMbEmail(String mbEmail) {
		this.mbEmail = mbEmail;
	}
	public String getMbBirthYear() {
		return mbBirthYear;
	}
	public void setMbBirthYear(String mbBirthYear) {
		this.mbBirthYear = mbBirthYear;
	}
	public String getMbPoint() {
		return mbPoint;
	}
	public void setMbPoint(String mbPoint) {
		this.mbPoint = mbPoint;
	}
	public String getMbAdmin() {
		return mbAdmin;
	}
	public void setMbAdmin(String mbAdmin) {
		this.mbAdmin = mbAdmin;
	}
	
	
}
